﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipIt
{
    class Program
    {
        static void Main(string[] args)
        {
            //make a new list object called Shipper for all of this
            List<IShippable> Shipper = new List<IShippable>();
            string menu = "Choose from the following options:\n \n1.Add a Bicycle to the shipment \n2.Add a Lawn Mower to the Shipment \n3.Add a Baseball Glove to the shipment \n4.Add Crackers to the shipment. \n5. List Shipment Items. \n6.Compute Shipping Charges.";
            while (true)
            {
                Console.WriteLine(menu);
                string choice = Console.ReadLine();// puts out the menue and waits for a key strock... still need to catch the key and set it to a output. 
                // start the menue choices
                if (choice == "1")
                {
                    //add a bicycleclass object to the list Shipper
                    Shipper.Add(new BicycleClass());
                    Console.WriteLine("1 Bicycle has been added.\nPress any key to return to the menu.");
                    Console.ReadKey();
                }
                else if(choice =="2")
                {
                    //add a LawnMowerClass object to the list Shipper
                    Shipper.Add(new LawnMowerClass());
                    Console.WriteLine("1 Lawn Mower has been added.\nPress any key to return to the menu.");
                    Console.ReadKey();
                }
                else if(choice =="3")
                {
                    //add a BaseballGloveClass object to the list of Shipper
                    Shipper.Add(new BaseballGlovesClass());
                    Console.WriteLine("1 Baseball Glove has been added.\nPress any key to return to the menu.");
                    Console.ReadKey();
                }
                else if(choice =="4")
                {
                    //add a CrackersClass object to the list Shipper
                    Shipper.Add(new CrackersCLass());
                    Console.WriteLine("1 Crackers has been added.\nPress any key to return to the menu.");
                    Console.ReadKey();
                }
                else if(choice =="5")
                {
                    //group then list all objects in list Shipper
                    int Bicical = 0;
                    int LawnMower = 0;
                    int BaseballGlove = 0;
                    int Crackers = 0;
                    foreach (BicycleClass bicycleClass in Shipper.OfType<BicycleClass>()){ Bicical += 1; }
                    foreach(LawnMowerClass lawnMowerClass in Shipper.OfType<LawnMowerClass>()){ LawnMower += 1; }
                    foreach(BaseballGlovesClass baseballGlovesClass in Shipper.OfType<BaseballGlovesClass>()) { BaseballGlove += 1; }
                    foreach(CrackersCLass crackersCLass in Shipper.OfType<CrackersCLass>()){ Crackers += 1; }
                    string Bike;
                    string Glove;
                    string Lawn;
                    if (Bicical == 1) Bike = "1 Bicycle";
                    else Bike = Bicical.ToString() + " Bicycles";
                    if (BaseballGlove == 1) Glove = "1 Baseball Glove";
                    else Glove = BaseballGlove.ToString() + " Baseball Gloves";
                    if (LawnMower == 1) Lawn = "1 Lawn Mower";
                    else Lawn = LawnMower.ToString() + " Lawn Mowers";
                    Console.WriteLine("Shipment Manifest \n" + Bike + "\n" + Lawn + "\n" + Glove + "\n" + Crackers.ToString() + " Crackers" + "\nPress any key to return to the menu.");
                    Console.ReadKey();
                }
                else if(choice =="6")
                {
                    //add up all costs of objects in the list and output the total... end the loop
                    decimal total;
                    decimal TotalBikes = 0;
                    int TotalGloves = 0;
                    int TotalMowers = 0;
                    int TotalCrackers = 0;
                    IShippable bikeCost = new BicycleClass();
                    IShippable GloveCost = new BaseballGlovesClass();
                    IShippable MowerCost = new LawnMowerClass();
                    IShippable CrackerCost = new CrackersCLass();
                    foreach(BicycleClass bicycleClass in Shipper.OfType<BicycleClass>()) { TotalBikes += 1; }
                    foreach(BaseballGlovesClass baseballGlovesClass in Shipper.OfType<BaseballGlovesClass>()){ TotalGloves += 1; }
                    foreach(LawnMowerClass lawnMowerClass in Shipper.OfType<LawnMowerClass>()){ TotalMowers += 1; }
                    foreach(CrackersCLass crackersCLass in Shipper.OfType<CrackersCLass>()){ TotalCrackers += 1; }
                    total = (TotalBikes * bikeCost.ShipCost) + (TotalGloves * GloveCost.ShipCost) + (TotalMowers * MowerCost.ShipCost) + (TotalCrackers * CrackerCost.ShipCost);
                    decimal Total = Math.Round(total, 2);
                    Console.WriteLine("Total shipping cost for this order are $" + Total + ". To end the program hit any key.");
                    Console.ReadKey();
                    break;
                }
                else
                {
                    Console.WriteLine("Did not understand input.");
                }
            }
        }
    }
    interface IShippable
    {
        decimal ShipCost { get; }
        string Product { get; }
    }
    class BicycleClass : IShippable
    {
        decimal IShippable.ShipCost => 20.5m;
        string IShippable.Product => "Bicycle";
    }
    class LawnMowerClass : IShippable
    {
        decimal IShippable.ShipCost => 24m;
        string IShippable.Product => "Lawn Mower";
    }
    class BaseballGlovesClass : IShippable
    {
        decimal IShippable.ShipCost => 3.23m;
        string IShippable.Product => "Baseball Glove";
    }
    class CrackersCLass : IShippable
    {
        decimal IShippable.ShipCost => .57m;
        string IShippable.Product => "Crackers";
    }
}
